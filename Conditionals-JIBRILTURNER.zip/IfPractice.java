//if statement practice

import java.util.Scanner;

public class IfPractice
{
	public static void main(String args[])
	{
		//define and instantiate a Scanner named keyboard
      	Scanner keyboard = new Scanner(System.in);
		// prompt the user to enter a real number

		//read in a double and save it in a variable named value

		//print out ben if value is greater than 1000

		//print out sam if value is less than -2000

		// ask the person's age (an int).
		// Print adult if 21 or over, else print minor
	}
}

