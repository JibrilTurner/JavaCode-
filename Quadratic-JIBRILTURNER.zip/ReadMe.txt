Purpose: This lab was designed to teach you more about objects, input, output formatting, and
the Math class.

Description:
Given the values of a quadratic equation, calculate the two possible answers.

Quadratic class: You need to complete the Quadradic class.
1. This is a class that represents a quadratic equation. The three coordinates of the equation and the two possible roots are
stored in the instance variables.

2. Complete the two constructors. The default constructor should initialize everything to zero

3. Complete setEquation - set the coordinates to the new values in the parameters

4. Code calcRoots. You will need to rewrite the quadratic formula into two Java equations.
Use Math.sqrt() and remember order of operations!

5. Use the printf method when coding print() so that only two decimal places are displayed.
(System.out.printf("%.3f\n", 9.541724);   //outs 9.542)

Application / testing code: You will need to create an Application Class. Save it as QuadApp in
your labs folder.
1. import java.util.Scanner;
2. Declare variables
1. Create a keyboard object
2. Create a new Quadratic equation object using the default constructor
3. Delcare variables a, b, and c.
3. Input the coefficients and constant: a, b, c.
4. Use setEquation() method to change the equation.
5. Call the method calcRoots() to calculate the two roots of the equation
6. Call method print.
7. We want more than one example in our output. You can copy and paste the code 2 more
times like TriangleAreaApp, or copy the for loop from MathMethods and put your code
inside the loop.
 

Sample Output:
Enter a :: 5
Enter b :: -8
Enter c :: 3
root one :: 1.00
root two :: 0.60
 
Enter a :: 3
Enter b :: 2
Enter c :: -7
root one :: 1.23
root two :: -1.90
 
Enter a :: 9
Enter b :: 6
Enter c :: 1
root one :: -0.33
root two :: -0.33