
import java.util.Scanner;
public class Main
{
    public static void main(String [] args) 
    {
      Scanner kb = new Scanner(System.in); //kb is short for keyboard it is a var 

      Quadratic test = new Quadratic(); // this is a new Quadratic obj with the default aka =0 

      int a, b, c; 
      
      System.out.print("enter a ::");

      a = kb.nextInt();

      System.out.print("enter b ::");
      b = kb.nextInt();

      System.out.print("enter c ::");
      c = kb.nextInt();

      test.setEquation(a, b, c);
      test.calcRoots();
      test.print();

    }
} // end of main
