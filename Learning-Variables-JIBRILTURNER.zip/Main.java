public class Main
{
    public static void main(String[] args)
    {
    	int x;    		// declares variable
    	double a;		// declares variable

    	x = 5;			// stores the value of 5 in x
    	String s;		// declares a String reference, but nothing stored yet

    	System.out.println("x");			// prints a string
    	System.out.println(x);				// prints the stored value
    	System.out.println("a: " + a);		// prints a label, then the stored value
    	s = ("This is a string because it is inside quoatation marks!"); 	// assigns a very long value to s

    	int y = 4;							// declares a new variable, sets it to 4
    	System.out.println(x + y);			// prints the result, does not store it

    	s = "I changed my mind.  This is now my string.";  // reassign the reference (need to make a new string)

    	x = y;								// changes the value of x, but not y
    	x = y + 5;							// changes the value of x, but not y

    	x = a;  // error!					// overflow!

    }
}