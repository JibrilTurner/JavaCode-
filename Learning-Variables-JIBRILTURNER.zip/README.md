 

```
Try to compile this file.  Note that the file will not compile correctly, there will be errors
```

```
- you need to fix the problem!  

Once the file can compile, change the file so that it only uses the following variables:

a String called name that stores YOUR NAME
a String called grade that stores a letter grade you would like (A, B, C, or F).
an int to store the year YOU were born
an int to store the year you will graduate high school
Now modify the program so it prints out the values of your variables.  
```

```
The output should have the same format as shown below.  
```

```
YOU MUST PRINT THE VALUE OF YOUR VARIABLES TO RECEIVE CREDIT!

Sample Output:

My name is Suzy Student.

I would like to earn an A on this lab

I was born in 1988.

I will graduduate in 2016.
```