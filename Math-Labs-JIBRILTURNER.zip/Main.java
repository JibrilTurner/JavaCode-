/*
/*
Name:Jibril
Prd:b2
Description:P = 2L + 2W and A = L * W
Date: oct 22 thu

I received help from... my brain
*/



import java.util.Scanner;
class Main {
    public static void main (String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        System.out.println("L:");
        double length = scanner.nextDouble();
        System.out.println("W:");
        double width = scanner.nextDouble();
        double area = length*width;
        System.out.println("Area is:"+area);
        double perimeter = 2*length+2*width;
        System.out.println("perimeter is:"+perimeter);
    }
}

