/*
Name:Jibril

Description:

Always read the comments and make sure to leave comments as you are coding. You want to document your work.

*/
import java.util.Scanner; 

class Main 
{
  public static void main(String[] args) 
  {
    Scanner Keyboard = new Scanner(System.in);
    System.out.println("imput ex");

    int numA, numB;
    System.out.print("enter a number:: ");
    numA = Keyboard.nextInt();

    System.out.print("enter another number:: ");
    numB = Keyboard.nextInt();

    int sum = numA + numB; 
    System.out.println("sum is " + sum);

    System.out.println("\nDoubles");
  System.out.print("Enter a decimal number:: ");

    double x = Keyboard.nextDouble();
    System.out.println("This is a double"+ x);
    
    System.out.println("\nStrings");
    System.out.println("Enter a word::");

    String w = Keyboard.next();
    System.out.println("your word was:" + w);

    System.out.println("enter a line::");
    String line = Keyboard.nextLine();

    System.out.println(line);


  }//end of class
}//end of main