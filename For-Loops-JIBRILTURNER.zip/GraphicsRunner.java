import javax.swing.JFrame;

public class GraphicsRunner extends JFrame
{
	private static final int WIDTH = 600;
	private static final int HEIGHT = 600;

	public GraphicsRunner()
	{
		super("For Loops and Graphics");
		setSize(WIDTH,HEIGHT);
	//getContentPane().add(new RandomColoredBoxes());
		//getContentPane().add(new ForLoopCircles());
	//getContentPane().add(new Diagonals());
  //getContentPane().add(new LineFill());
  getContentPane().add(new ForLoops());

		setVisible(true);
	}

	public static void main( String args[] )
	{
		GraphicsRunner run = new GraphicsRunner();
		run.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}