public class Main {
    public static void main(String[] args) {


        String s = "Happy Thursday";
        String p = "Hasta la vista baby";
        String k = "”Kawhapunga”";

        System.out.println( s.length());
        System.out.println( k.length());
        System.out.println( p.length());

        System.out.println(p+s+k.length());

        System.out.println( s.indexOf("a") );
        System.out.println( k.indexOf("a") );
        System.out.println( p.indexOf("a") );

        System.out.println( s.substring(12,13) );
        System.out.println( k.substring(9,10) );
        System.out.println( p.substring(16,17) );


        System.out.println( s.substring(11,14) );
        System.out.println( p.substring(6,14) );

        System.out.println( s.substring(11,14) );

        System.out.print( s.substring(1,2) );
        System.out.print( s.substring(4,5) );
        System.out.print( s.substring(8,9) );
        System.out.print( s.substring(1,2) );
        System.out.println( s.substring(4,5) );

        System.out.print( k.substring(1,2) );
        System.out.print( k.substring(3,4) );
        System.out.print( k.substring(5,7) );
        System.out.println( k.substring(8,9) );

        System.out.print(s);
        System.out.print(",");
        System.out.print(k);
        System.out.print(",");
        System.out.print(p);




        
    }
}
  