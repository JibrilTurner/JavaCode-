All of this will be coded in your Main.java file

1. create a string named s that will store the phrase “Happy Thursday”
2. create a string named k that will store the phrase ”Kawhapunga”
3. create a string named p that will store the phrase “Hasta la vista baby”
4. find the length of string s
5. find the length of string k
6. find the length of string p
7. find the length of all 3 strings combined
8. find the index of “a” for each string (this will be 3 separate lines of code)
9. find the last index of “a” for each string as well
10. how will you get the output of “day” in string s
11. how will you get the output of “la vista” in string p
12. how will you get the output of “a y u a y” from string s using concatenation
13. how will you get the output of “a h p g” from string k using concatenation
14. how will you get the output of “Happy Thursday, Kawhapunga, Hasta la vista baby”
15. replace string k with “the ninja turtles are the coolest”
16. replace string s with “Arnold”
17. how will you get the output "Arnold’s famous quote in Terminator was “Hasta la vista baby” " HINT use your escape sequences 