
//Name -Jibril Turner
//Date -
//Class - B2
//Lab  -Name LAb
//actual name of this class is NameApp

/*
  YOU WILL NOT CHANGE ANYTHING ON THIS FILE BESIDES ADDING YOUR HEADER AT THE TOP AND ADDING YOUR NAME TO THE LIST AT THE BOTTOM IN CODE
*/

public class Main
{
	public static void main ( String[] args )
	{
		Name person = new Name("Sally Baker");
		System.out.println(person.getFirst());
		System.out.println(person.getLast());
		System.out.println(person.getInitials());
		System.out.println(person + "\n\n");

		person.setName("John Doe");
		System.out.println(person.getFirst());
		System.out.println(person.getLast());
		System.out.println(person.getInitials());
		System.out.println(person + "\n\n");

		person.setName("Sammy Lammy");
		System.out.println(person.getFirst());
		System.out.println(person.getLast());
		System.out.println(person.getInitials());
		System.out.println(person + "\n\n");

		person.setName("Benny Programmer");
		System.out.println(person.getFirst());
		System.out.println(person.getLast());
		System.out.println(person.getInitials());
		System.out.println(person + "\n\n");

		person.setName("Sandy Painter");
		System.out.println(person.getFirst());
		System.out.println(person.getLast());
		System.out.println(person.getInitials());
		System.out.println(person + "\n\n");

		person.setName("Jibril Turner");
		System.out.println(person.getFirst());
		System.out.println(person.getLast());
		System.out.println(person.getInitials());
		System.out.println(person + "\n\n");
	}
}