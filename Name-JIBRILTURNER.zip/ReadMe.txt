Purpose: This lab was designed to teach you more about objects and the String class.

Description: Write a program that will store a complete first and last name.  The program will
return the first and last names as independent words and will also return the person's initials.

1. The NameApp is to test the Name class. All changes need to be made in the Name class

2. The name of a person is stored in the instance variable name. Complete the constructors.Refer to the comments in the Name class.

3. You will need to complete the modifier method - setName

4. Code the accessor methods which all return a String. You will need to use the String methods charAt(), indexOf(), substring(x), and substring(x, y).

Refer to the String notes for help.
 
Sample Output:
Sally
Baker
S.B.
Sally Baker

John
Doe
J.D.
John Doe

Sammy
Lammy
S.L.
Sammy Lammy

Benjamin
Programmer
B.P.
Benjamin Programmer

Arabella
Singer
A.S.
Arabella SingerKL;