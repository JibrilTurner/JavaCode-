 

For every "new" file you are supposed to create on your Lab 0a- Oc, you will not be creating a new file. You will create a block comment to comment out the "old" file and start the new section. Mrs. Garcia will go over this in class.

There are 3 parts to this lab.

Part 1: Lab 0a

    Your First Cup of Java was Hello World!. As you have seen, we can replace and/or add other statements inside the main method. Read over the Java code below. What do you think it will do when you compile and run it?  Write your own answer in a block comment below your class heading. 

System.out.print(“Hello”); 

System.out.print(“Buenos” + “Dias”);

System.out.println(“Bonjour”);

System.out.println(); 

System.out.println(“How do you greet another?”); 

Now copy the statements into your program. Compile and run the program.What was the actual out put the actual output? Write that in the block comment below your header. 

Part 2: Lab 0b

1. Block comment the class main section. 

2. In the main method, add statements to print your first and last name on the first line, your address on the second line, skip the third line, and print your phone number on the fourth line.

3. Include correct comments at top of program :/*   Lab ob – displaying text. */ 

Part 3: Lab0c

Write  a  program  using  escape  sequences  that  produces  the  following  run  output.  Make  sure  you  have  added  documentation  (comments)  at the  top of your program giving me  your information  and the program description. Show me the program when you have finished. ( PLEASE LOOK AT THE LAB INSTRUCTIONS IN CANVAS TO HELP YOU WITH THIS PART ) :)

                                          *

                                          |\      

                                          | \ 

                                  ------|--\--

                                  \              / 

                    \~\~\~\~\~\~~\            /\~\~\~\~\~\~\~  

                                      ------- 

                 \~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~\~ 

                           the “Yankee Clipper” 